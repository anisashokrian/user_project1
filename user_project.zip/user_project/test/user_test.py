from data_access.database_manager import create_table_user

create_table_user()

