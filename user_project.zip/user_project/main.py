from data_access.database_manager import *
create_table_user()

from tools.validation import *
from view.user_view import *